/*:
 [← Previous Question](@previous)                    [Next Question →](@next)
 
 ### Question 4
 
 ## 👣 Reducing the Footprint
 
 The people of the Land of Tigerspike have become very aware of their carbon footprint and they need a programmer to make a function that can work out the total carbon footprint of all of their citizens, so they can try to 'reduce' their carbon emmisons.
 */

import Foundation

// MARK: Citizen

struct Citizen {
    var carbonFootprint: Int
}

func totalCarbonFootprint(forCitizens citizens: [Citizen]) -> Int {
    // TODO: Your solution here!
    return 0
}

// MARK: Tests

let ecoFriendlyCitizen = Citizen(carbonFootprint: 35)
let averageCitizen = Citizen(carbonFootprint: 220)
let gasGuzzlingCitizen = Citizen(carbonFootprint: 1000)

assertEqual(totalCarbonFootprint(forCitizens: [ecoFriendlyCitizen]), 35)
assertEqual(totalCarbonFootprint(forCitizens: [ecoFriendlyCitizen, averageCitizen, gasGuzzlingCitizen]), 1255)
assertEqual(totalCarbonFootprint(forCitizens: []), 0)
