/*:
 [← Previous Question](@previous)                    [Next Question →](@next)
 
 ### Question 3
 
 ## 😷🔢 Allergic to Math
 
 The people of Tigerspike are allergic to some numbers, specifically numbers which are multiple of 3 and 5. That's why they decided to get rid of them and replace them with words.
 
 To help them to automate this process you must scan the incoming arrays for multiples of 3 and replace them with 'Tiger', multiples of 5 should be replaced them with 'Spike'. If a number is a multiple of both 3 and 5 then replace it with 'Tigerspike'. All other numbers should be returned as a string containing that number.
 */

import Foundation

func filterForAllergies(_ input: [Int]) -> [String] {
    // TODO: Your solution here!
    return []
}

// MARK: Tests

assertTrue(filterForAllergies([1, 4]) == ["1", "4"])
assertTrue(filterForAllergies([9]) == ["Tiger"])
assertTrue(filterForAllergies([25]) == ["Spike"])
assertTrue(filterForAllergies([15]) == ["Tigerspike"])
assertTrue(filterForAllergies([1, 3, 5, 8]) == ["1", "Tiger", "Spike", "8"])
assertTrue(filterForAllergies([14, 15, 16, 17]) == ["14", "Tigerspike", "16", "17"])
assertTrue(filterForAllergies([]) == [])
