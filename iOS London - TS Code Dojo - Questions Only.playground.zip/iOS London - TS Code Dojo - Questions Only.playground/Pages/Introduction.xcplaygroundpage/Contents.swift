/*:
 
 # 📱 iOS London
 
 ## Welcome to the Code Dojo! Our goal today is to improve the lives of people from the ancient land of Tigerspike through technology.
 
 ### Instructions
 
 In each question, you will find a problem for the people of Tigerspike. You can solve each problem by implementing a function which solves the issue and thereby improving the lives of every citizen.

 Below each function are some tests.
 
 When all of the tests pass, you have likely produced a valid solution! ✅
 
 - Note: You are not allowed to change the tests. That's cheating! 🤥
 
 An example is provided below:
 */

func startsWithTigerspike(_ text: String) -> Bool {
    
    // Your solution goes here, like this
    return text.hasPrefix("Tigerspike")
    
}

// MARK: Tests

assertTrue(startsWithTigerspike("Tigerspike"))
assertFalse(startsWithTigerspike("NotTigerspike"))

/*:
 Are you ready to help the people from the land of Tigerspike and be there code writing hero? 😄
 
 [Proceed to Question 1 →](@next)
 */
