/*:
 [← Previous Question](@previous)                    [Next Question →](@next)
 
 ### Question 2

## 🏥 Record Heart Rate

 At the Tigerspike hospital they keep a record of all of their patients' heart rates.

 We need you to implement an algorhythm which is able to take an array of people and then return an array containing the highest heart rate of each person.
 
 - Note: 🧟‍♂️ Beware of zombies.
 */

import Foundation

// MARK: Person

struct Person {
    let name: String
    var hearRateArray: [Int]
}

func highestHeartRate(forPeople people: [Person]) -> [Int] {
    // TODO: Your solution here!
    return []
}

// MARK: Tests

var patienceHeartRateData = [
    Person(name: "Eduardo Palacios" , hearRateArray: [100, 75, 84, 65, 70]),
]

let micah = Person(name: "Micah Simmons", hearRateArray: [80, 65, 48, 96])
let michael = Person(name: "Michael Lake", hearRateArray: [88, 55, 92, 90])


assertTrue(highestHeartRate(forPeople: patienceHeartRateData) == [100])

patienceHeartRateData.append(micah)
assertTrue(highestHeartRate(forPeople: patienceHeartRateData) == [100, 96])


patienceHeartRateData.append(michael)
assertTrue(highestHeartRate(forPeople: patienceHeartRateData) == [100, 96, 92])


assertTrue(highestHeartRate(forPeople: [micah, michael]) == [96, 92])


let zombie = Person(name: "Zombie", hearRateArray: [])
assertTrue(highestHeartRate(forPeople: [zombie]) == [0])


assertTrue(highestHeartRate(forPeople: []) == [])
