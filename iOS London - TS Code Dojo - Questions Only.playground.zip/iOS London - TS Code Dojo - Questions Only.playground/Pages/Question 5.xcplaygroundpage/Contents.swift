/*:
 [← Previous Question](@previous)                    [Next Question →](@next)
 
 ### Question 5
 
 ## 💧 Particle Filter
 
 The Land of Tigerspike has many great rivers. Each river contains particles and some of those particles have become toxic.

 Your job is to implement a function which can filter out all of the toxic particles from each river, returning the clean rivers.
 */

import Foundation

// MARK: River, Particle and ParticleType

struct River {
    var particles: [Particle] = []
}

struct Particle {
    let type: ParticleType
}

enum ParticleType {
    case harmless
    case toxic
}

func filterToxicParticles(fromRivers rivers: [River]) -> [River] {
    // TODO: Your solution here!
    return []
}

// MARK: Tests

let toxicRiver = River(particles: [Particle(type: .toxic), Particle(type: .toxic)])
let mixedRiver = River(particles: [Particle(type: .toxic), Particle(type: .harmless)])
let cleanRiver = River(particles: [Particle(type: .harmless), Particle(type: .harmless)])
let emptyRiver = River(particles: [])

if let filteredToxicRiver = filterToxicParticles(fromRivers: [toxicRiver]).first {
    assertEqual(filteredToxicRiver.particles.count, 0)
}

if let filteredMixedRiver = filterToxicParticles(fromRivers: [mixedRiver]).first {
    assertEqual(filteredMixedRiver.particles.count, 1)
}

if let filteredCleanRiver = filterToxicParticles(fromRivers: [cleanRiver]).first {
    assertEqual(filteredCleanRiver.particles.count, 2)
}

if let filteredEmptyRiver = filterToxicParticles(fromRivers: [emptyRiver]).first {
    assertEqual(filteredEmptyRiver.particles.count, 0)
}

let noRivers = filterToxicParticles(fromRivers: [])
assertEqual(noRivers.count, 0)
