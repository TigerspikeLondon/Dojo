/*:
 [← Introduction](@previous)                    [Next Question →](@next)
 
 ### Question 1
 
 ## 👩‍⚕️ Healthy Beat
 
 Doctors at the the hostpital in the Land of Tigerspike have noticed that people with a heart rate above 100 beats per minute or below 60 beats per minute are at risk of heart problems.

 Your job is to complete the function below and return false if the given array contains at least one reading which is either greater than (or equal to) 100 or less than (or equal to) 60.
 */

import Foundation

func allHeartBeatsAreHealthy(in heartBeatsArray: [Int]) -> Bool {
    // TODO: Your solution here!
    return false
}

// MARK: Tests

assertTrue(allHeartBeatsAreHealthy(in: [65, 70, 80]))
assertFalse(allHeartBeatsAreHealthy(in: [105, 45]))
assertFalse(allHeartBeatsAreHealthy(in: [60, 65, 70, 80]))
assertFalse(allHeartBeatsAreHealthy(in: [100, 65, 70, 80]))
assertFalse(allHeartBeatsAreHealthy(in: [105, 45, 65, 70, 80]))
assertTrue(allHeartBeatsAreHealthy(in: []))
