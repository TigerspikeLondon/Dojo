/*:
 [← Previous Question](@previous)
 
 ### Question 6
 
 ## 🔬GATTACA
 
 The dedicated scientists from Tigerspike's Institute of Awesome Research & Development are trying to find mutations in Tigerspikers. So far they know that each DNA symbol has a corresponding counterpart symbol:
 
    A <—> T
    C <—> G
 
 And they now that DNA is never a single symbol, but a chain:
 
    "ATTGC" == "TAACG"
 
 The Tigerspike scientists have also discovered the X gene. The X gene is notated as a '*' in the chain. The scientists worked out that if the X gene is present the corresponding DNA symbols become:
 
    A <—> G
    T <—> C
 
 The X gene also reverses the chain of DNA symbols. So if we receive a chain such as 'ATT*GC' we will get back:
 
    'TACCG'
 
 Although the scientists have recognised this trend in DNA they haven't been able to write a formula for converting a DNA chain into its counterpart.
 
 - Note: The DNA chain can be corrupted and will be impossible to analyse. In this case the chain returned should be empty.
 */

import Foundation

class DNA {
    class func helixPair(_ DNAChain: String?) -> String {
        // TODO: Your solution here!
        return ""
    }
}

// MARK: Tests

assertEqual(DNA.helixPair("CCCC"), "GGGG")
assertEqual(DNA.helixPair("TTTT"), "AAAA")

assertEqual(DNA.helixPair("GATTACA"), "CTAATGT")
assertEqual(DNA.helixPair("CTAATGT"), "GATTACA")

assertEqual(DNA.helixPair("TATG*"), "ACGC")
assertEqual(DNA.helixPair("*T*A*T*G*"), "ACGC")
assertEqual(DNA.helixPair("CA*TA"), "GCGT")

assertEqual(DNA.helixPair("ABCDEF"), "")
assertEqual(DNA.helixPair("****"), "")
assertEqual(DNA.helixPair(""), "")
assertEqual(DNA.helixPair(nil), "")
